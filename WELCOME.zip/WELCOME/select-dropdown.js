$(document).ready(function(){
    $('inputState').selectpicker();
});